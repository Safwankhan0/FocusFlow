// Load username from localStorage or default
let username = localStorage.getItem('username') || 'User';
document.getElementById('greeting').textContent = `Hey, ${username}!`;

const taskList = document.getElementById('task-list');
const addTaskContainer = document.getElementById('add-task-container');

let tasks = [];

function updateProgress() {
  const total = tasks.length;
  const done = tasks.filter(t => t.done).length;
  const percent = total === 0 ? 0 : Math.floor((done / total) * 100);
  const progressBar = document.getElementById('progress-bar');
  const text = document.querySelector('.percentage');
  progressBar.setAttribute('stroke-dasharray', `${percent}, 100`);
  text.textContent = `${percent}%`;
}

function renderTasks() {
  taskList.innerHTML = '';
  tasks.forEach((task, i) => {
    const div = document.createElement('div');
    div.className = `task ${task.done ? 'done' : ''}`;
    div.innerHTML = `
      <span>${task.text}</span>
      <div class="task-buttons">
        <button onclick="toggleDone(${i})" title="Mark Done">✔️</button>
        <button onclick="editTask(${i})" title="Edit Task">📝</button>
        <button onclick="deleteTask(${i})" title="Delete Task">🗑️</button>
      </div>
    `;
    taskList.appendChild(div);
  });
  updateProgress();
}

function toggleDone(index) {
  tasks[index].done = !tasks[index].done;
  renderTasks();
}

function editTask(index) {
  const newText = prompt('Edit your task:', tasks[index].text);
  if (newText) {
    tasks[index].text = newText;
    renderTasks();
  }
}

function deleteTask(index) {
  tasks.splice(index, 1);
  renderTasks();
}

// Add new task inline input logic
function resetAddTaskBox() {
  addTaskContainer.innerHTML = `<button id="add-task-btn">+</button>`;
  const newAddBtn = document.getElementById('add-task-btn');
  newAddBtn.addEventListener('click', showAddTaskInput);
}

function showAddTaskInput() {
  addTaskContainer.innerHTML = `
    <input type="text" id="new-task-input" placeholder="Type your new task..." autofocus />
    <button class="submit-task-btn">Add</button>
  `;

  const input = document.getElementById('new-task-input');
  const submitBtn = addTaskContainer.querySelector('.submit-task-btn');

  function addTask() {
    const text = input.value.trim();
    if (text) {
      tasks.push({ text, done: false });
      renderTasks();
      resetAddTaskBox();
    }
  }

  submitBtn.addEventListener('click', addTask);

  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      addTask();
    } else if (e.key === 'Escape') {
      resetAddTaskBox();
    }
  });
}

// Initialize "+" button listener
resetAddTaskBox();

// Render initially
renderTasks();

// Make functions accessible globally for inline onclick handlers
window.toggleDone = toggleDone;
window.editTask = editTask;
window.deleteTask = deleteTask;
