// Animated dots in Welcome screen
let dots = 0;
setInterval(() => {
  const text = document.getElementById("animated-text");
  if (text) {
    dots = (dots + 1) % 4;
    text.innerText = "Enter your name" + ".".repeat(dots);
  }
}, 500);

// Navigate to todo.html with name
function enterApp() {
  const name = document.getElementById('username').value.trim();
  if (name) {
    localStorage.setItem('username', name);
    window.location.href = 'todo.html';
  }
}


// Load name and tasks
window.onload = function () {
  const greeting = document.getElementById("greeting");
  const name = localStorage.getItem("focusflow_name");
  if (greeting && name) greeting.innerText = `Hey, ${name}!`;

  loadTasks();
};

// Add task input display
function showTaskInput() {
  document.getElementById("task-input-box").style.display = "block";
  document.getElementById("task-input").focus();
}

// Add task
function addTask() {
  const input = document.getElementById("task-input");
  const taskText = input.value.trim();
  if (taskText) {
    const tasks = JSON.parse(localStorage.getItem("focusflow_tasks") || "[]");
    tasks.push({ text: taskText, done: false });
    localStorage.setItem("focusflow_tasks", JSON.stringify(tasks));
    input.value = "";
    loadTasks();
    updateProgress();
  }
}

// Load tasks
function loadTasks() {
  const container = document.getElementById("task-list");
  if (!container) return;
  container.innerHTML = "";

  const tasks = JSON.parse(localStorage.getItem("focusflow_tasks") || "[]");

  tasks.forEach((task, index) => {
    const taskEl = document.createElement("div");
    taskEl.className = "task";

    const content = document.createElement("span");
    content.innerText = task.text;
    if (task.done) content.style.textDecoration = "line-through";
    content.onclick = () => {
      task.done = !task.done;
      localStorage.setItem("focusflow_tasks", JSON.stringify(tasks));
      loadTasks();
      updateProgress();
    };

    const editBtn = document.createElement("button");
    editBtn.innerText = "🖉";
    editBtn.onclick = () => {
      const newText = prompt("Edit task:", task.text);
      if (newText !== null) {
        tasks[index].text = newText;
        localStorage.setItem("focusflow_tasks", JSON.stringify(tasks));
        loadTasks();
      }
    };

    const deleteBtn = document.createElement("button");
    deleteBtn.innerText = "🗑";
    deleteBtn.onclick = () => {
      tasks.splice(index, 1);
      localStorage.setItem("focusflow_tasks", JSON.stringify(tasks));
      loadTasks();
      updateProgress();
    };

    taskEl.appendChild(content);
    taskEl.appendChild(editBtn);
    taskEl.appendChild(deleteBtn);
    container.appendChild(taskEl);
  });

  updateProgress();
}

// Update progress
function updateProgress() {
  const tasks = JSON.parse(localStorage.getItem("focusflow_tasks") || "[]");
  const done = tasks.filter(t => t.done).length;
  const percent = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  const circle = document.getElementById("progress");
  if (circle) circle.innerText = `${percent}%`;
}
